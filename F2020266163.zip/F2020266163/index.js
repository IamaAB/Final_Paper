const express = require("express");
const mongoose = require("mongoose");
const Blogs = require("./models/blog");
const app = express();

//connect to mongoDB

mongoose.Promise = global.Promise;
mongoose
  .connect('mongodb://localhost:27017/Database_final_1',{
    useNewUrlParser: true,
})
  .then(() => {
    console.log(`Connected to MongoDB`);
    console.log(`Congratulations..`);
  })
  .catch((err) => {
    console.log(`Oh No ERROR!`);
    console.log(err);
  });

//parsing data form req.body
app.use(express.urlencoded({ extended: false }));

//static assets
app.use(express.static("public"));

//templating engine
app.set("view engine", "ejs");

//fake database call to get recepie data

//home route




//show all recepies
app.get("/blogs", async (req, res) => {
  try {
    const blogs = await Blogs.find();
    res.render("blogfol/blogs", { blogs });
  } catch (error) {
    console.log(`Oh No ERROR!!`);
    res.send(error.message);
  }
});


//render create new blog page
app.get("/blogs/new", (req, res) => {
  res.render("blogfol/new");
});
app.get("/create", (req, res) => {
  res.render("blogfol/new");
});

//create new blog
app.post("/blogs", async (req, res) => {
  const { title, text, img, category, date, model, roof } = req.body;

  const blog = new Blogs({
    title,
    text,
    img,
    category,
    date,
    model,
    roof,
  });
  try {
    await blog.save();
    res.redirect("blogs");
  } catch (error) {
    console.log(`Oh No ERROR!!!`);
    res.send(error.message);
  }
});
// create
app.post("/create", async (req, res) => {
  const { title, text, img, category, date, model, roof } = req.body;

  const blog = new Blogs({
    title,
    text,
    img,
    category,
    date,
    model,
    roof,
  });
  try {
    await blog.save();
    res.redirect("create");
  } catch (error) {
    console.log(`Oh No ERROR!!!!`);
    res.send(error.message);
  }
});

//show details page
app.get("/blogs/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const foundblog = await Blogs.findById(id);

    res.render("blogfol/show", { foundblog });
  } catch (error) {
    console.log(`Oh No ERROR!`);
    res.send(error.message);
  }
});

// search

app.get("/",(req,res)=>{
  if(req.query.category){
      let user={};
          user = {category:req.query.category.split(',')};
         Blogs.find(user).then(blog=>{
          if(!blog){       
              res.render("Error")
                    }
                    else{  
                        console.log(blog)
                    res.render("blogfol/category",{blog});
                }}).catch(err=>{
                    res.render("Error");
                })
                   }
        
else
{
  Blogs.find().then(blog=>{
      res.render("home",{blog})
  })
.catch(()=>{
  res.render("Error")
  })}
})
app.get("/home/:id",(req,res)=>{
  if(req.params.id){
     const id = req.params.id;
     Blogs.findById(id).then(blog=>{
         if(!blog){
             res.render("Error")
         }
         else{
             res.render("blogfol/show",{blog})
         }
     }).catch(err=>{
         res.render("Error")
     })
 }
 else{
     res.render("error")
 }
});
// ///////////////////////////////////

//edit blog form
app.get("/blogs/:id/edit", async (req, res) => {
  const id = req.params.id;
  const foundblog = await Blogs.findById(id);
  res.render("blogfol/update", { foundblog });
});

//update route
app.post("/blogs/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const foundblog = await Blogs.findByIdAndUpdate(id, req.body, {
      new: true,
    });
    console.log(foundblog);
    res.redirect("/blogs");
  } catch (error) {
    console.log(`Oh NO ERROR!`);
    res.send(error.message);
  }
});

//Delete blog
app.get("/delete/:id", async (req, res) => {
  try {
    await Blogs.findByIdAndDelete(req.params.id);
    res.redirect("/blogs");
  } catch (error) {
    console.log(`Oh No ERRROR!`);
    res.send(error.message);
  }
});
app.get("*", (req, res) => {
  res.render("Not_found");
});
app.listen(7500, () => {
  console.log("Server is Working at PORT 7500");
});
