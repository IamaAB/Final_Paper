const mongoose = require("mongoose");

const blog = new mongoose.Schema({
  title: {
    type: String,
    
  },
  text: {
    type: String,
  },
  img: {
    type: String,
  },
  category: {
    type: String,
    required: true,
  },
  date:{
   type:Date,
  
  },
  model:{
    type:String,
  },
  roof:{
 type: String,
  },
});

const blogs = mongoose.model("Blog", blog);

module.exports = blogs;
